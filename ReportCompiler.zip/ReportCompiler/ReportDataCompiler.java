import java.io.*;
import java.text.*;
import java.util.*;
import java.nio.file.Files;
import java.util.zip.GZIPInputStream;

/**
* The ReportDataCompiler collects all raw data files following the "meas-" 
* naming convention and compiles them into useful data within a .csv file for 
* later use. The user must specify a folder containing the raw data files 
* when running the application. The names of the raw data files must have 
* "meas-" followed by the date they were created in the format of 
* "yyyyMMddHHmmss" and can be any type of text file. The data at the time
* of the creation of this application should begin with the date in the same 
* format preceded by the '@' character and each following line should have 
* each item delimited by a comma in the following format:
*     column_name,current_value,min_value,max_value,avg_value
* 
* As of version 1.5, the application will seek out the raw data files in directories 
* that are grandchildren of the original directory the user targeted. The application 
* will process raw data files that been compressed as if they have been pulled 
* directly out of the data repository. This allows the user to just pull the 
* directory out of the repository and not have to individually un-gzip each file.
* 
* If the raw data occurs before the last processed date in the compiled data file, 
* we want to skip that data file and move on to the next one. Future versions should 
* take into consideration whether the raw data is occurring before the start of the 
* compiled data file. Or if the raw data occurs between the first and last processed 
* date whether the data has already been processed. As it currently stands, we don't 
* have a use for retroactively processing data we might have missed.
* 
* This application builds the raw data into the compiled .csv file named 
* after the directory storing the raw files. If running from the 
* Windows CLI, the user should pass the directory name as the first argument 
* after the application name:
* 
* java ReportDataCompiler Data
* 
* @author Wayne Roswell
* @version 1.5
* @since 2019-04-15
*/
public class EnergyReportDataCompiler {
    //Boolean check - if the headers are set then this flag gets set.
    public static boolean check1 = false;
    
    //Boolean check - if the file exists or the headers have already been written 
    //to the file this flag gets set.
    public static boolean check2 = false;
    
    //String containing the list of file headers.
    public static String headers = null;
    
    //Name of the file we're writing to.
    public static File cFileName = null;
    
    //lastDate is the last processed date in the targeted CSV file
    public static Date lastDate = null;
    
    //currentDate is the date and time being processed in the current raw data file.
    public static Date currentDate = null;
    
    public static void main (String[] args) throws java.io.IOException {
        cFileName = new File(args[0] + "_data.csv");
        System.out.println(cFileName.getPath());
        createCompiledFile();
        
        File folder = new File(args[0]);
        if (folder.isDirectory()) {
            processFiles(folder);
        } else {
            System.out.println(args[0] + " is not a directory containing the requisite data files. Please try again.");
        }
    }
    
    /**
     * Creates the compiled data file if it doesn't exist and sets the lastDate Object if 
     * it does exist.
     * @throws IOException
     */
    public static void createCompiledFile() throws java.io.IOException{
        if (!cFileName.isDirectory()) {
            check2 = (!(cFileName.createNewFile()) && cFileName.length() != 0);
            if (check2) {
                getLastProcessedDate();
            }
        }
    }
    
    /**
     * Processes any raw data files in the directory passed in by the user.
     * @param File folder File passed in by user. Should be a folder containing the 
     *                    raw data files to be processed.
     * @throws IOException
    */
    public static void processFiles(File folder) throws java.io.IOException {
        String[] data = new String[2];
        for (File fileEntry : folder.listFiles()) {
            if (fileEntry.isDirectory()) {
                cFileName = new File(fileEntry.getParentFile(), fileEntry.toString() + "_data.csv");
                createCompiledFile();
                processFiles(fileEntry);
            } else if (!fileEntry.isDirectory() && fileEntry.toString().contains("meas-") && "csv".equals(getFileExtension(fileEntry.getName()))){
                checkFiles(fileEntry);
            } else if (!fileEntry.isDirectory() && fileEntry.toString().contains("meas-") && ("gz".equals(getFileExtension(fileEntry.getName())) || "gzip".equals(getFileExtension(fileEntry.getName())))) {
                File dFile = decompressFile(fileEntry);
                checkFiles(dFile);
            }
        }
    }
    
    /**
     * Checks to see if we should be writing the processed data to the compiled file. 
     * If the processed data occurs before the last recorded date, skip over this file, 
     * otherwise, add the data to the compiled file.
     * @param File fileEntry The file to be processed.
     * @throws IOException
     */
    public static void checkFiles(File fileEntry) throws java.io.IOException{
        if (fileEntry != null) {
            String[] data = processDataFile(fileEntry);
            if (lastDate == null || (lastDate != null && currentDate.after(lastDate))) {
                compileData(data);
            }
            
            getLastProcessedDate();
        }
    }
    
    /**
     * Retrieves the file extension of the current file.
     * @param String fullName Name of the current file.
     * @return String File extension of the current file.
     */
    public static String getFileExtension(String fullName) {
        String fileName = new String();
        int dotIndex = 0;
        
        if (fullName != null) {
            fileName = new File(fullName).getName();
            dotIndex = fileName.lastIndexOf('.');
        }
        return (dotIndex == -1) ? "" : fileName.substring(dotIndex + 1);
    }
    
    /**
     * Decompresses any files that are compressed using the .gzip format. In the original
     * example, it was actually .gz files. Returns the decompressed raw data file or null
     * if unable to do so.
     * @param File file The file to be decompressed.
     * @return File The decompressed file or null if unable to do so.
     * @throws IOException
     */
    public static File decompressFile(File file) {
        byte[] buffer = new byte[1024];
        String outputFile = file.toString().substring(0, file.toString().lastIndexOf("."));
        
        try {
            FileInputStream fileIn = new FileInputStream(file.toString());
            GZIPInputStream gzipInputStream = new GZIPInputStream(fileIn);
            FileOutputStream fileOutputStream = new FileOutputStream(outputFile);
            
            int bytes_read = 0;
            
            while ((bytes_read = gzipInputStream.read(buffer)) > 0) {
                fileOutputStream.write(buffer, 0, bytes_read);
            }
            
            gzipInputStream.close();
            fileOutputStream.close();
            
            return new File(outputFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Writes all the compiled data to the final .CSV file if 'headers' is null it 
     * writes the headers. If the file currently exists or the headers have already 
     * been written to the file then we're not going to include the headers pulled 
     * from the file.
     * @param String[] data Compiled data the first item in the string is the headers from 
     *                      the data files, the second is the data itself.
     * @throws IOException
    */
    public static void compileData(String[] data) throws java.io.IOException{
        String cData = (data[1].substring(0, (data[1].length() - 1)));
        FileWriter fw = new FileWriter(cFileName, true);
        BufferedWriter writer = new BufferedWriter(fw);
        if (headers == null && data[0].length() > 5) {
            headers = (data[0].substring(0, (data[0].length() - 5)));
            writer.write(headers);
        }
        writer.write(cData);
        writer.close();
        fw.close();
    }
    
    /**
     * Reads each line from the current raw data file and returns the compiled data 
     * set including headers.
     * @param File file Raw data file for processing.
     * @return String[] Processed data including headers. Headers are stored in the 
     *                  first item of the array, the data is in the second.
     * @throws IOException
    */
    public static String[] processDataFile(File file) throws java.io.IOException {
        String line = new String();
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String heads = new String("");
        String data = new String("");
        while ((line = br.readLine()) != null) {
            if (!("".equals(line))) {
                if (!check2) {
                    heads = heads.concat(retrieveData(line, 0));
                }
                data = data.concat(retrieveData(line, 1));
                if (lastDate != null && currentDate.before(lastDate)) {
                    break;
                }
            }
        }
        
        data = data.concat("\n");
        br.close();
        fr.close();
        return new String[]{heads, data};
    }
    
    /**
     * Breaks up the data into useful subsets to be added to the compiled data set. 
     * Returns different data sets depending on the index passed in.
     * @param String line The current line of the raw data file being processed.
     * @param String index The index of the data item within the current line. 
     *                     (i.e. header = 0, current value = 1, min = 2, max = 3, avg = 4)
     * @return String Compiled data set derived from the current raw data file.
    */
    public static String retrieveData(String line, int index) {
        String data = new String();
        if (line.contains("@20") && index == 1) {
            data = "\n" + decodeDate(line);
            if (check1) {
                check2 = true;
            } else {
                check1 = true;
            }
        } else if (line.contains("@20") && index == 0) {
            data = "date";
        } else {
            data = "," + line.split(",")[index];
        }
        return data;
    }
    
    /**
     * Decodes the date and time from the first line of the raw data file prefixed by '@' 
     * and in the format of yyyyMMddHHmmss and converts it to the "MM/dd/yyyy HH:mm" format.
     * @param String line The line from the raw data file containing the date the file was created.
     * @return String The converted date to be used in the final data file for processing.
    */
    public static String decodeDate(String line) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        currentDate = sdf.parse(line, new ParsePosition(1));
        sdf.applyPattern("MM/dd/yyyy HH:mm");
        return sdf.format(currentDate).toString();
    }
    
    /**
     * Retrieves the last processed date from the target CSV file to be compared to the new data.
     * @return String Last processed date within the target CSV file.
     * @throws IOException
    */
    public static void getLastProcessedDate() throws java.io.IOException {
        FileReader fr = new FileReader(cFileName);
        BufferedReader br = new BufferedReader(fr);
        String lastLine = null, temp;
        while ((temp = br.readLine()) != null) {
            if (!("".equals(temp))) {
                lastLine = temp;
            }
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        try {
            lastDate = sdf.parse(lastLine);
        } catch (Exception ex) {
            check2 = false;
            lastDate = null;
        }
        
        br.close();
        fr.close();
    }
}